package com.grocery.order_history;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderHistoryApplication.class, args);
	}

}
