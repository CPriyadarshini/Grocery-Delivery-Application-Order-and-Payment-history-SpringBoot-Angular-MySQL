package com.grocery.order_history;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderHistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
